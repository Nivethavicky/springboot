package com.example.demo.controller1;
@RestController

public class restApiController {

}

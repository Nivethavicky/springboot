package com.example.demo.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/class")
public class rest1ApiController {
	@GetMapping("/method")
  public String getAll() {
	  return "hello this is my first api";
  }
	
	@GetMapping("/method1")
	  public String getAll1() {
		  return "method1 is called";
	  }	
	
	
	@GetMapping("/method2")
	  public String getAll2() {
		  return "method2 is called here";
	  }	
	
}

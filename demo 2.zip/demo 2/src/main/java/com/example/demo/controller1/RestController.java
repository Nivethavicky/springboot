package com.example.demo.controller1;

public @interface RestController {

}

package com.example.EmployeModel;

import jakarta.persistence.Entity;

@Entity
public class EmployeModel {
	
  private int empId;
  
  public int getEmpId() {
	return empId;
}

public void setEmpId(int empId) {
	this.empId = empId;
}

public String getEmpName() {
	return empName;
}

public void setEmpName(String empName) {
	this.empName = empName;
}

public String getEmpNum() {
	return empNum;
}

public void setEmpNum(String empNum) {
	this.empNum = empNum;
}

private String empName;
  
  private String empNum;
  
  
  
  
  
  
}
